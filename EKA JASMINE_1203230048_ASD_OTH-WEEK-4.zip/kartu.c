#include <stdio.h>

// Fungsi untuk mendapatkan nilai numerik dari karakter kartu
int get_value(char c) {
    if (c == 'J')
        return 11;
    else if (c == 'Q')
        return 12;
    else if (c == 'K')
        return 13;
    else if (c == '1')
        return 10;
    else
        return c - '0';
}

// Fungsi untuk melakukan pengurutan dan mengembalikan jumlah pertukaran yang dilakukan
int swapping(int n, char *cards) {
    int swaps = 0;
    for (int i = 0; i < n - 1; i++) {
        int min_idx = i;
        for (int j = i + 1; j < n; j++) {
            // Memeriksa apakah nilai kartu saat ini lebih kecil dari nilai kartu terkecil yang ditemukan sebelumnya
            if (get_value(cards[j]) < get_value(cards[min_idx])) {
                min_idx = j;
            }
        }
        // Jika indeks minimum bukanlah indeks saat ini, maka lakukan pertukaran
        if (min_idx != i) {
            char temp = cards[i];
            cards[i] = cards[min_idx];
            cards[min_idx] = temp;
            swaps++; // Menghitung pertukaran yang dilakukan
        }
    }
    return swaps; // Mengembalikan jumlah pertukaran
}

int main() {
    int n;
    scanf("%d", &n); // Membaca jumlah kartu

    char cards[n];
    // Membaca karakter kartu sebanyak n kali
    for (int i = 0; i < n; i++) {
        scanf(" %c", &cards[i]);
    }

    // Panggil fungsi untuk melakukan pengurutan dan simpan jumlah pertukaran
    int swaps = swapping(n, cards);

    // Menampilkan jumlah pertukaran yang dilakukan
    printf("%d\n", swaps);

    return 0;
}
