#include <stdio.h>

// Fungsi untuk memeriksa apakah posisi (x, y) berada di dalam papan catur berukuran 8x8
int cekValiditasPosisi(int x, int y) {
    return (x >= 0 && x < 8 && y >= 0 && y < 8);
}

// Fungsi untuk menandai semua langkah yang mungkin dilakukan oleh kuda pada papan catur
void tandaiLangkahKuda(int i, int j, int ukuran, int *papanCatur) {
    // Langkah langkah yang mungkin dilakukan oleh kuda
    int pergeseranX[] = {2, 1, -1, -2, -2, -1, 1, 2};
    int pergeseranY[] = {1, 2, 2, 1, -1, -2, -2, -1};

    // Menandai setiap langkah yang mungkin dilakukan oleh kuda
    for (int k = 0; k < 8; k++) {
        int xSelanjutnya = i + pergeseranX[k];
        int ySelanjutnya = j + pergeseranY[k];
        if (cekValiditasPosisi(xSelanjutnya, ySelanjutnya)) {
            *(papanCatur + xSelanjutnya * ukuran + ySelanjutnya) = 1; // Menandai langkah kuda dengan nilai 1
        }
    }
}

int main() {
    int i, j;
    printf("Masukkan posisi untuk kuda dalam rentang 0-7: ");
    scanf("%d %d", &i, &j); // Membaca input posisi i dan j

    int ukuran = 8; // Ukuran papan catur
    int papanCatur[ukuran][ukuran]; // Array 2D untuk papan catur

    // Inisialisasi papan catur dengan nilai awal 0
    for (int x = 0; x < ukuran; x++) {
        for (int y = 0; y < ukuran; y++) {
            papanCatur[x][y] = 0;
        }
    }

    tandaiLangkahKuda(i, j, ukuran, (int *)papanCatur); // Memanggil fungsi untuk menandai langkah kuda

    // Menampilkan papan catur setelah langkah kuda ditandai
    printf("Papan catur setelah langkah kuda ditandai:\n");
    for (int x = 0; x < ukuran; x++) {
        for (int y = 0; y < ukuran; y++) {
            printf("%d ", papanCatur[x][y]);
        }
        printf("\n");
    }

    return 0;
}
